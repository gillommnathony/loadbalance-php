var canRunAds = true;
